-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  sam. 05 mai 2018 à 10:39
-- Version du serveur :  5.7.19
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `piscine`
--

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `id_commentaire` int(11) NOT NULL,
  `utilisateur_id` int(11) NOT NULL,
  `id_publication` int(11) NOT NULL,
  `texte` text NOT NULL,
  `heure` date DEFAULT NULL,
  PRIMARY KEY (`id_commentaire`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `demande`
--

DROP TABLE IF EXISTS `demande`;
CREATE TABLE IF NOT EXISTS `demande` (
  `id_demande` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `tiers_id` int(10) NOT NULL,
  `etat` enum('Accepté(e)','Refusé(e)') NOT NULL,
  PRIMARY KEY (`id_demande`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `emploie`
--

DROP TABLE IF EXISTS `emploie`;
CREATE TABLE IF NOT EXISTS `emploie` (
  `id_emploie` int(10) NOT NULL AUTO_INCREMENT,
  `nom` varchar(430) DEFAULT NULL,
  `salaire` int(40) DEFAULT NULL,
  `type` enum('CDD','CDI','INTERIM','STAGE') DEFAULT NULL,
  `duree` varchar(40) DEFAULT NULL,
  `utilisateur_id` int(10) DEFAULT NULL,
  `photo` varchar(250) DEFAULT 'photo\\p3.jpg',
  `nomp` text,
  PRIMARY KEY (`id_emploie`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `emploie`
--

INSERT INTO `emploie` (`id_emploie`, `nom`, `salaire`, `type`, `duree`, `utilisateur_id`, `photo`, `nomp`) VALUES
(1, 'Stage en Start-Up chez parrot', NULL, NULL, NULL, NULL, 'photo\\p4.jpg', 'Vanessa Soussan'),
(4, 'webdesign ', NULL, NULL, NULL, NULL, 'photo\\p2.jpg', 'Jeanne Lavilette'),
(10, 'CDD Carrefour', NULL, NULL, NULL, NULL, 'photo\\p5.jpg', 'Hugo Dubesset'),
(12, 'Manageur de projet', NULL, NULL, NULL, NULL, 'photo\\p6.jpg', 'Clement Halbeher'),
(14, 'Projet Picine ', NULL, NULL, NULL, NULL, 'photo\\p3.jpg', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `experience`
--

DROP TABLE IF EXISTS `experience`;
CREATE TABLE IF NOT EXISTS `experience` (
  `id_experience` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `entreprise` varchar(40) NOT NULL,
  `domaine` int(40) NOT NULL,
  `resume` longtext NOT NULL,
  `poste` varchar(40) NOT NULL,
  PRIMARY KEY (`id_experience`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `jaime`
--

DROP TABLE IF EXISTS `jaime`;
CREATE TABLE IF NOT EXISTS `jaime` (
  `id_jaime` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `id_publication` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `id_message` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `tiers_id` int(10) NOT NULL,
  `heure` datetime(6) NOT NULL,
  `texte` text NOT NULL,
  PRIMARY KEY (`id_message`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE IF NOT EXISTS `notification` (
  `id_notification` int(10) NOT NULL,
  `titre` varchar(40) NOT NULL,
  `texte` text NOT NULL,
  `date` datetime(6) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `tiers_id` int(10) NOT NULL,
  PRIMARY KEY (`id_notification`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `partage`
--

DROP TABLE IF EXISTS `partage`;
CREATE TABLE IF NOT EXISTS `partage` (
  `id_partage` int(10) NOT NULL,
  `tiers_id` int(10) NOT NULL,
  `id_publication` int(10) NOT NULL,
  `heure` date DEFAULT NULL,
  PRIMARY KEY (`id_partage`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `photo`
--

DROP TABLE IF EXISTS `photo`;
CREATE TABLE IF NOT EXISTS `photo` (
  `id_photo` int(10) NOT NULL,
  `utilisateur_id` int(10) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id_photo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `photo`
--

INSERT INTO `photo` (`id_photo`, `utilisateur_id`, `url`) VALUES
(0, 0, '0'),
(1, 12, 'photo\\moi.jpg'),
(3, 1, 'photo\\n.png'),
(4, 1, 'photo\\cv.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `publication`
--

DROP TABLE IF EXISTS `publication`;
CREATE TABLE IF NOT EXISTS `publication` (
  `id_publication` int(10) NOT NULL AUTO_INCREMENT,
  `utilisateur_id` int(10) DEFAULT NULL,
  `heure` datetime(6) DEFAULT '2018-05-04 07:12:00.000000',
  `texte` longtext,
  `fichier` varchar(250) NOT NULL DEFAULT 'photo\\n.png',
  `sentiment` enum('Content(e)','Triste','Exité(e)','Fier(e)','Enervé(e)','Fatigué(e)') DEFAULT NULL,
  `nom` text,
  `prenom` text,
  `photo` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_publication`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `publication`
--

INSERT INTO `publication` (`id_publication`, `utilisateur_id`, `heure`, `texte`, `fichier`, `sentiment`, `nom`, `prenom`, `photo`) VALUES
(1, 1, '2018-05-04 07:12:00.000000', 'Hey voici mon CV', 'photo\\cv.jpg', 'Fier(e)', 'Simon Lhuillier', 'Simon', 'photo\\p3.jpg'),
(2, 1, '2018-05-10 00:00:00.000000', 'Embauché !', 'photo\\em.jpg', 'Exité(e)', 'Hugo Dubesset', '', 'photo\\p5.jpg'),
(20, 16, '2018-05-10 00:00:00.000000', 'Voici ma nouvelle app !', 'photo\\app.jpg', 'Fatigué(e)', 'Jeanne Lavillette', '', 'photo\\p2.jpg'),
(4, 13, '2018-05-21 00:00:00.000000', 'Connaissez vous ce service génial !?', 'photo\\ser.jpg', 'Fier(e)', 'Clement Halbeher', '', 'photo\\p6.jpg'),
(16, NULL, '2018-06-04 07:12:00.000000', 'Au chommage', 'photo\\seul.jpg', NULL, 'Hugo Dubesset', 'Hugo', 'photo\\p5.jpg'),
(14, NULL, '2018-05-04 07:12:00.000000', 'Hey c\'est moii', 'photo\\moi.jpg', NULL, 'Simon Lhuillier', 'Simon', 'photo\\p3.jpg'),
(15, NULL, '2018-05-04 07:12:00.000000', 'Nouvelle recrue !', 'photo\\p1.jpg', NULL, 'Simon Lhuillier', 'Simon', 'photo\\p3.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `utilisateur_id` int(10) NOT NULL,
  `nom` text,
  `prenom` text,
  `date_naissance` date DEFAULT NULL,
  `sexe` enum('M','F') DEFAULT NULL,
  `telephone` text,
  `promo` enum('ING1','ING2','ING3','ING4','ING5','ING6','ALUMNI') DEFAULT NULL,
  `campus` enum('PARIS','LYON') DEFAULT NULL,
  `adresse` varchar(50) DEFAULT NULL,
  `situation` enum('LICENCE','MASTER','DOCTORA','THESE','CHOMAGE','CDI','CDD','ENTREPRENEUR') DEFAULT NULL,
  `type` enum('UTILISATEUR','ADMINISTRATEUR') DEFAULT 'UTILISATEUR',
  `photo_profil` varchar(250) DEFAULT 'phiphi.jpg',
  `photo_couverture` varchar(250) DEFAULT 'photo\\5.png',
  `resume` longtext,
  `email` varchar(40) DEFAULT NULL,
  `mdp` varchar(40) DEFAULT NULL,
  `age` int(6) DEFAULT NULL,
  `suivre` text,
  PRIMARY KEY (`utilisateur_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`utilisateur_id`, `nom`, `prenom`, `date_naissance`, `sexe`, `telephone`, `promo`, `campus`, `adresse`, `situation`, `type`, `photo_profil`, `photo_couverture`, `resume`, `email`, `mdp`, `age`, `suivre`) VALUES
(1, 'Lhuillier', 'Simon', '1997-11-19', 'M', '0778213368', 'ING3', 'PARIS', '5 rue Perthuis CLAMART', 'LICENCE', 'UTILISATEUR', 'photo\\p3.jpg', 'photo\\3.png', 'Hey moi c\'est simon est je suis en projet piscine', 'sim97@hotmail.fr', 'ok', 0, 'oui'),
(11, 'ADMIN', 'ADMIN', '1997-08-07', 'M', '2345678', 'ALUMNI', 'PARIS', 'azertyuio', 'ENTREPRENEUR', 'ADMINISTRATEUR', 'phiphi.jpg', NULL, NULL, 'admin@hotmail.fr', 'admin', 0, 'oui'),
(12, 'Dubesset', 'Hugo', '1997-06-01', 'M', '0609047436', 'ING3', 'PARIS', '1 ter rue basse', 'LICENCE', 'UTILISATEUR', 'photo\\p5.jpg', 'photo\\5.png', NULL, 'hugodpw@orange.fr', 'caca', 0, 'oui'),
(13, 'Halbeher', 'Clement', '1996-08-11', 'M', '0667543256', 'ING3', 'PARIS', '4 rue Pigale', 'CHOMAGE', 'UTILISATEUR', 'photo\\p6.jpg', 'photo\\6.png', NULL, 'clement@hotmail.fr', 'mdp', 0, 'non'),
(15, 'Lavillettee', 'Jeanne', '1978-07-21', 'F', '123456789', 'ING1', 'PARIS', 'Ico', 'CDD', 'UTILISATEUR', 'photo\\p2.jpg', 'photo\\2.png', NULL, 'jeanne@hotmail.fr', 'mdp', 0, 'oui'),
(17, 'Fellon', 'Maxime', '1997-02-08', 'M', '0656787689', 'ING2', 'PARIS', '17 rue Pasteur', 'LICENCE', 'UTILISATEUR', 'photo\\p4.jpg', 'photo\\4.png', NULL, 'maxime@gmail.com', 'mdp', NULL, 'non');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
